# 🏥 CliniKids — Guia de Instalação no iPhone

## Como publicar no Vercel (gratuito)

### Passo 1 — Crie uma conta gratuita
Acesse https://vercel.com e crie uma conta com seu e-mail ou Google.

### Passo 2 — Suba os arquivos
1. No painel do Vercel, clique em **"Add New Project"**
2. Escolha **"Deploy from template"** → selecione **"Browse Templates"** → ou use **"Upload"**
3. Arraste a pasta `clinikids` inteira para o Vercel
4. Clique em **"Deploy"**

> Alternativa mais fácil: instale o Vercel CLI e rode:
> ```bash
> npm i -g vercel
> cd clinikids
> vercel
> ```

### Passo 3 — Acesse o link gerado
O Vercel vai gerar um link como: `https://clinikids-xxxx.vercel.app`

---

## Como instalar no iPhone (iOS)

1. Abra o **Safari** no iPhone
2. Acesse o link do seu app (ex: `https://clinikids-xxxx.vercel.app`)
3. Toque no botão **Compartilhar** (quadrado com seta ↑)
4. Role para baixo e toque em **"Adicionar à Tela de Início"**
5. Confirme o nome **"CliniKids"** e toque em **"Adicionar"**

✅ O app vai aparecer na sua tela inicial como um ícone, sem barra do Safari!

---

## Arquivos do projeto

```
clinikids/
├── index.html      ← App principal
├── manifest.json   ← Configuração PWA (ícone, nome, cor)
├── sw.js           ← Service Worker (funciona offline)
└── vercel.json     ← Configuração do servidor
```
